import { NgModule } from '@angular/core';
import { Routes, RouterModule,PreloadAllModules   } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { FormComponent } from './components/form/form.component';
import { L1formComponent } from './components/l1form/l1form.component';
import { L2formComponent } from './components/l2form/l2form.component';
import { UseridComponent } from './components/userid/userid.component';
import { Level2Component } from './components/level2/level2.component';
import { AdminComponent } from './components/admin/admin.component';





const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'userlogin', component:UserloginComponent},
  {path:'form', component:FormComponent},
  {path:'l1form', component:L1formComponent},
  {path:'l2form', component:L2formComponent},
  {path:'userid', component:UseridComponent},
  {path:'level2', component:Level2Component},
  {path:'admin', component:AdminComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
