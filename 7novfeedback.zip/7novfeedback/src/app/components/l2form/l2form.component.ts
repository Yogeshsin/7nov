import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-l2form',
  templateUrl: './l2form.component.html',
  styleUrls: ['./l2form.component.css']
})
export class L2formComponent implements OnInit {

  l2Form: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;


  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.l2Form = this.formBuilder.group({
      candidate: ['', Validators.required]
    
    });


  }

  
  Submit() {
    this.submitted = true;
    // If validation failed, it should return 
    // to Validate again
    if (this.l2Form.invalid) {
    return;
    }
  
    this.router.navigate(['/home']);
    }
   

}
