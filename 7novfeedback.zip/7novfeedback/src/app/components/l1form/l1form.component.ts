import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})

export class L1formComponent implements OnInit {
  ngForm: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;

  textBoxDisabled = true;
  
  toggle(){
    this.textBoxDisabled = !this.textBoxDisabled;
  }

textBoxDisabled1 = true;
  
  toggle1(){
    this.textBoxDisabled1 = !this.textBoxDisabled1;
  }

// myClickFunction(event) { 
//   alert("Registration Successful");
//   console.log(event);
// }


  list: any = [
    {id: 1, name: 'Java'},
    {id: 2, name: 'Angular 6'},
    {id: 3, name: 'Node Js'},
    {id: 4, name: 'Express Js'}
  ];
  current = 1;
  log = '';

  logDropdown(id: number): void {
    const NAME = this.list.find((item: any) => item.id === +id).name;
    this.log += `Selected skill is ${NAME} \n`;
  }

  name: any;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.ngForm = this.formBuilder.group({
      cname: ['', Validators.required],
      desc: ['', Validators.required],
      skill: ['', Validators.required],
      flexibility: ['', Validators.required],
      ename: ['', Validators.required],
      ecode: ['', Validators.required],
    });
  }
  
  onSubmit() {
    this.submitted = true;
    // If validation failed, it should return 
    // to Validate again
    if (this.ngForm.invalid) {
    return;
    }
  
    this.router.navigate(['level2']);
    }
   
    


}
